# Queue Management System for College Services (Java Swing)
Course: CGB1201 - Java Programming

Students get a token for Office, Library, Fees Section, Certificates or Administrative
Services, see their live position and estimated waiting time, and staff call tokens in order
(priority first). A public "Now Serving" display board shows the token at every counter.

## Open in Eclipse
1. Eclipse > File > Import > General > **Existing Projects into Workspace**
2. Select this folder (or the zip file) > Finish.
   (Needs JDK 11 or newer; developed and tested on JDK 21.)
3. Open `src/qms/App.java` > right click > **Run As > Java Application**.
4. Optional logic test: `src/qms/SelfTest.java` > Run As > Java Application (prints 20 PASS lines).

Data files are created in the `data/` folder (users.txt, tokens.txt) so data stays after restart.

## Logins
* Staff: `admin` / `admin123`
* Student: click "New Student? Register" and create an account.

## Demo script (about 4 minutes)
1. Run App. Log in as **admin**. Click **Add Demo Data** (fills all 5 queues).
2. Click **Open Display Board** and move the board window to the side (or second screen).
3. Run App a second time (Run As again) - this is the **student window**.
   Register a student, log in, choose **Library**, tick Priority if you want, click **Generate Token**.
   Show the position and estimated wait. In the staff window, select that token in the table and click **Priority On/Off** (priority is decided by staff only).
   (Both windows share the files in `data/` and refresh every 2 seconds.)
4. In the staff window: choose service **Library**, Counter 1, click **Call Next**.
   The board updates, and the student window shows a pop-up "Your token is being called".
5. Click **Complete** (or **Skip (No-show)**). Show the statistics line at the bottom.
6. Show **Walk-in Token**, then **Clear Today** to reset before the next demo.

## Files (package qms)
App, Nav, LoginPanel, StudentPanel, StaffPanel, DisplayBoard, BoardPanel, UI   - presentation layer (Swing)
QueueService                                                                    - business logic
DataStore                                                                       - data access (file based; replaceable by JDBC/MySQL)
Token, User, ServiceType                                                        - model
SelfTest                                                                        - console tests
